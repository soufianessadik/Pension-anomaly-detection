import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import joblib
import os
from sklearn.preprocessing import RobustScaler
from torch.utils.data import Dataset, DataLoader
import warnings
warnings.filterwarnings('ignore')

FEATURES_INPUT = [
    'TOTAL_BRUT', 'TOTAL_MUTU', 'ir_9999',
    'TOTAL_CONT', 'TOTAL_PREL', 'af_20000',
    'Ratio_Mutu', 'Ratio_cont', 'Ratio_prel', 'Ratio_ir',
]

FEATURES_DETECT = [
    'TOTAL_BRUT',
    'TOTAL_MUTU',
    'ir_9999',
    'TOTAL_CONT',
    'TOTAL_PREL',
    'af_20000',
]

COLS_NO_TRANSFORM = []

FEATURES   = FEATURES_INPUT
MAX_LEN    = 17
N_FEATURES = len(FEATURES_INPUT)

TRAIN_RATIO = 0.70
VAL_RATIO   = 0.10
TEST_RATIO  = 0.20

SEUIL_PERCENTILE = 99

DATE_MIN_ANNEE = 2025
DATE_MIN_MOIS  = 1
DATE_MAX_ANNEE = 2026
DATE_MAX_MOIS  = 5

SCALERS_PATH = 'models/lstm_ae_scalers.pkl'
MODEL_PATH   = 'models/lstm_ae_model.pt'
os.makedirs('models', exist_ok=True)


def get_device():
    if not torch.cuda.is_available():
        print("GPU non disponible -> CPU")
        return torch.device('cpu')
    try:
        t = torch.zeros(1).cuda()
        _ = t + t
        del t
        print(f"GPU compatible : {torch.cuda.get_device_name(0)}")
        return torch.device('cuda')
    except Exception as e:
        print(f"GPU incompatible -> CPU : {e}")
        return torch.device('cpu')

DEVICE = get_device()


def in_window(annee, mois):
    annee = int(annee)
    mois  = int(mois)
    apres_min = (annee > DATE_MIN_ANNEE) or (annee == DATE_MIN_ANNEE and mois >= DATE_MIN_MOIS)
    avant_max = (annee < DATE_MAX_ANNEE) or (annee == DATE_MAX_ANNEE and mois <= DATE_MAX_MOIS)
    return apres_min and avant_max


def split_clients(data: pd.DataFrame, seed: int = 42) -> tuple:
    mask_window = data.apply(
        lambda r: in_window(r['annee'], r['mois']), axis=1
    )
    clients_in_window = data[mask_window]['numero_benef'].unique()
    all_clients       = data['numero_benef'].unique()
    clients_type2     = np.array([c for c in all_clients if c not in clients_in_window])
    clients_type13    = clients_in_window

    np.random.seed(seed)
    np.random.shuffle(clients_type13)

    n       = len(clients_type13)
    n_train = int(n * TRAIN_RATIO)
    n_val   = int(n * VAL_RATIO)

    c_train_13 = clients_type13[:n_train]
    c_val      = clients_type13[n_train : n_train + n_val]
    c_test     = clients_type13[n_train + n_val :]
    c_train    = np.concatenate([c_train_13, clients_type2])

    df_train = data[data['numero_benef'].isin(c_train)].copy().reset_index(drop=True)
    df_val   = data[data['numero_benef'].isin(c_val)].copy().reset_index(drop=True)
    df_test  = data[data['numero_benef'].isin(c_test)].copy().reset_index(drop=True)

    print(f"\n{'='*60}")
    print(f"SPLIT 70 / 10 / 20 PAR CLIENT")
    print(f"{'='*60}")
    print(f"Type 1+3 (fenetre)   : {len(clients_type13)} clients")
    print(f"Type 2   (anciens)   : {len(clients_type2)} clients -> train only")
    print(f"Train : {len(c_train)} clients - {len(df_train)} lignes")
    print(f"Val   : {len(c_val)} clients - {len(df_val)} lignes")
    print(f"Test  : {len(c_test)} clients - {len(df_test)} lignes")

    assert len(set(c_train_13) & set(c_test)) == 0
    assert len(set(c_train_13) & set(c_val))  == 0
    print("Aucun chevauchement OK")

    return df_train, df_val, df_test


def fit_scalers(df_train: pd.DataFrame) -> dict:
    scalers = {}
    cols    = [c for c in FEATURES if c in df_train.columns]

    print(f"\n{'='*60}")
    print(f"FIT SCALERS - TRAIN")
    print(f"{'='*60}")

    for col in cols:
        if col in COLS_NO_TRANSFORM:
            scalers[col] = None
            print(f"  {col:<25} -> ratio (0-100%), pas de scaler")
            continue

        non_zero = df_train[col][df_train[col] > 0]

        if len(non_zero) < 10:
            print(f"  {col:<25} -> trop de zeros, scaler identite")
            scalers[col] = None
            continue

        log_vals     = np.log1p(non_zero.clip(lower=0).values.reshape(-1, 1))
        scaler       = RobustScaler()
        scaler.fit(log_vals)
        scalers[col] = scaler

        pct_zero = (df_train[col] == 0).mean() * 100
        print(f"  {col:<25} median={scaler.center_[0]:.4f}  "
              f"IQR={scaler.scale_[0]:.4f}  zeros={pct_zero:.1f}%")

    joblib.dump(scalers, SCALERS_PATH)
    print(f"\nScalers sauvegardes : {SCALERS_PATH}")
    return scalers


def apply_scalers(df: pd.DataFrame, scalers: dict) -> pd.DataFrame:
    df   = df.copy()
    cols = [c for c in FEATURES if c in df.columns]

    for col in cols:
        if col not in scalers or scalers[col] is None:
            continue

        scaler  = scalers[col]
        vals    = df[col].values.copy()
        mask_nz = vals > 0

        if mask_nz.sum() == 0:
            continue

        log_nz          = np.log1p(vals[mask_nz].reshape(-1, 1))
        scaled          = scaler.transform(log_nz).flatten()
        result          = np.zeros_like(vals, dtype=np.float32)
        result[mask_nz] = np.clip(scaled, -3, 3)
        df[col]         = result

    return df


def inverse_scalers(values: np.ndarray,
                    col: str,
                    scalers: dict) -> np.ndarray:
    if col not in scalers or scalers[col] is None:
        return values
    scaler   = scalers[col]
    unscaled = scaler.inverse_transform(values.reshape(-1, 1)).flatten()
    return np.clip(np.expm1(unscaled), 0, None)


def build_sequences(df: pd.DataFrame,
                    scalers: dict,
                    max_len: int = MAX_LEN) -> tuple:
    df = apply_scalers(df, scalers)

    cols_feat = [c for c in FEATURES if c in df.columns]
    sequences = []
    masks     = []
    meta_rows = []

    for client, df_c in df.groupby('numero_benef'):
        df_c = df_c.sort_values('time_idx')

        df_window = df_c[
            df_c.apply(lambda r: in_window(r['annee'], r['mois']), axis=1)
        ]

        if len(df_window) > 0:
            df_c = df_window

        vals = df_c[cols_feat].fillna(0).values.astype(np.float32)
        T    = len(vals)

        if T > max_len:
            vals = vals[-max_len:]
            T    = max_len

        padded               = np.zeros((max_len, len(cols_feat)), dtype=np.float32)
        padded[max_len - T:] = vals

        mask               = np.zeros(max_len, dtype=np.float32)
        mask[max_len - T:] = 1.0

        sequences.append(padded)
        masks.append(mask)

        last_row = df_c.iloc[-1]
        meta_rows.append({
            'numero_benef'          : client,
            'affiliation_id'        : last_row.get('affiliation_id', ''),
            'code_payment_agregator': last_row.get('code_payment_agregator', ''),
            'mois'                  : last_row.get('mois', ''),
            'annee'                 : last_row.get('annee', ''),
            'n_mois'                : T,
        })

    sequences = np.array(sequences, dtype=np.float32)
    masks     = np.array(masks,     dtype=np.float32)
    meta      = pd.DataFrame(meta_rows)

    print(f"  Sequences : {sequences.shape}")
    print(f"  Masks     : {masks.shape}")

    return sequences, masks, meta, cols_feat


# classe SequenceDataset - wrapper PyTorch pour les séquences et les masques
class SequenceDataset(Dataset):
    def __init__(self, sequences, masks):
        self.sequences = torch.tensor(sequences, dtype=torch.float32)
        self.masks     = torch.tensor(masks,     dtype=torch.float32)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        return self.sequences[idx], self.masks[idx]


class LSTMAutoEncoder(nn.Module):
    def __init__(self,
                 n_features  : int,
                 hidden_size : int = 64,
                 latent_size : int = 32,
                 n_layers    : int = 2,
                 dropout     : float = 0.1):
        super().__init__()

        self.n_features  = n_features
        self.hidden_size = hidden_size
        self.latent_size = latent_size
        self.n_layers    = n_layers

        self.encoder = nn.LSTM(
            input_size   = n_features,
            hidden_size  = hidden_size,
            num_layers   = n_layers,
            batch_first  = True,
            dropout      = dropout if n_layers > 1 else 0,
        )

        self.encoder_fc = nn.Linear(hidden_size, latent_size)
        self.decoder_fc = nn.Linear(latent_size, hidden_size)

        self.decoder = nn.LSTM(
            input_size   = hidden_size,
            hidden_size  = hidden_size,
            num_layers   = n_layers,
            batch_first  = True,
            dropout      = dropout if n_layers > 1 else 0,
        )

        self.output_fc = nn.Linear(hidden_size, n_features)

    def forward(self, x, mask=None):
        batch_size = x.size(0)
        seq_len    = x.size(1)

        enc_out, (h_n, c_n) = self.encoder(x)

        if mask is not None:
            last_idx    = mask.long().sum(dim=1) - 1
            last_idx    = last_idx.clamp(min=0)
            offset      = seq_len - mask.long().sum(dim=1)
            real_idx    = (offset + last_idx).clamp(0, seq_len - 1)
            last_hidden = enc_out[torch.arange(batch_size), real_idx]
        else:
            last_hidden = enc_out[:, -1, :]

        z              = torch.tanh(self.encoder_fc(last_hidden))
        dec_input      = torch.relu(self.decoder_fc(z))
        dec_input      = dec_input.unsqueeze(1).repeat(1, seq_len, 1)
        dec_out, _     = self.decoder(dec_input)
        reconstruction = self.output_fc(dec_out)

        return reconstruction


def masked_mse_loss(reconstruction, target, mask):
    error         = (reconstruction - target) ** 2
    mask_expanded = mask.unsqueeze(-1)
    error_masked  = error * mask_expanded
    loss = error_masked.sum() / (mask_expanded.sum() * reconstruction.size(-1) + 1e-8)
    return loss


def train_lstm_ae(model        : LSTMAutoEncoder,
                  train_loader : DataLoader,
                  val_loader   : DataLoader,
                  n_epochs     : int = 100,
                  lr           : float = 0.001,
                  patience     : int = 5) -> LSTMAutoEncoder:

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, patience=3, factor=0.5
    )

    best_val_loss = float('inf')
    patience_ctr  = 0
    best_weights  = None

    print(f"\n{'='*60}")
    print(f"ENTRAINEMENT LSTM-AE")
    print(f"{'='*60}")
    print(f"Parametres : {sum(p.numel() for p in model.parameters()):,}")
    print(f"Device     : {DEVICE}")

    for epoch in range(n_epochs):
        model.train()
        train_loss = 0.0

        for seqs, masks in train_loader:
            seqs  = seqs.to(DEVICE)
            masks = masks.to(DEVICE)

            optimizer.zero_grad()
            recon = model(seqs, masks)
            loss  = masked_mse_loss(recon, seqs, masks)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_loss += loss.item()

        train_loss /= len(train_loader)

        model.eval()
        val_loss = 0.0

        with torch.no_grad():
            for seqs, masks in val_loader:
                seqs  = seqs.to(DEVICE)
                masks = masks.to(DEVICE)
                recon = model(seqs, masks)
                loss  = masked_mse_loss(recon, seqs, masks)
                val_loss += loss.item()

        val_loss /= len(val_loader)
        scheduler.step(val_loss)

        print(f"  Epoch {epoch+1:3d}/{n_epochs} | "
              f"Train={train_loss:.6f} | "
              f"Val={val_loss:.6f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_weights  = {k: v.clone() for k, v in model.state_dict().items()}
            patience_ctr  = 0
        else:
            patience_ctr += 1
            if patience_ctr >= patience:
                print(f"  Early stopping epoch {epoch+1}")
                break

    model.load_state_dict(best_weights)
    torch.save(model.state_dict(), MODEL_PATH)
    print(f"\nModele sauvegarde : {MODEL_PATH}")
    print(f"Meilleure val_loss : {best_val_loss:.6f}")

    return model


def compute_thresholds(model      : LSTMAutoEncoder,
                       sequences  : np.ndarray,
                       masks      : np.ndarray,
                       cols_feat  : list,
                       percentile : int = SEUIL_PERCENTILE) -> dict:
    model.eval()
    all_errors = {col: [] for col in cols_feat}

    dataset = SequenceDataset(sequences, masks)
    loader  = DataLoader(dataset, batch_size=256, shuffle=False)

    with torch.no_grad():
        for seqs_b, masks_b in loader:
            seqs_b  = seqs_b.to(DEVICE)
            masks_b = masks_b.to(DEVICE)
            recon_b = model(seqs_b, masks_b)

            error_b = (recon_b - seqs_b).abs().cpu().numpy()
            mask_np = masks_b.cpu().numpy()

            for b in range(error_b.shape[0]):
                real_idx = np.where(mask_np[b] == 1)[0]
                if len(real_idx) == 0:
                    continue
                for j, col in enumerate(cols_feat):
                    errors = error_b[b, real_idx, j]
                    all_errors[col].extend(errors.tolist())

    thresholds = {}
    print(f"\nSeuils par variable (P{percentile}) :")
    for col in cols_feat:
        if all_errors[col]:
            seuil = np.percentile(all_errors[col], percentile)
            thresholds[col] = seuil
            print(f"  {col:<25} : {seuil:.6f}")

    return thresholds


def detect_anomalies(model      : LSTMAutoEncoder,
                     sequences  : np.ndarray,
                     masks      : np.ndarray,
                     meta       : pd.DataFrame,
                     cols_feat  : list,
                     thresholds : dict,
                     scalers    : dict,
                     df_orig    : pd.DataFrame,
                     phase      : str = 'test') -> pd.DataFrame:
    model.eval()
    dataset = SequenceDataset(sequences, masks)
    loader  = DataLoader(dataset, batch_size=256, shuffle=False)

    all_errors = []

    with torch.no_grad():
        for seqs_b, masks_b in loader:
            seqs_b  = seqs_b.to(DEVICE)
            masks_b = masks_b.to(DEVICE)
            recon_b = model(seqs_b, masks_b)
            error_b = (recon_b - seqs_b).abs()
            all_errors.append(error_b.cpu().numpy())

    all_errors = np.concatenate(all_errors, axis=0)
    masks_np   = masks

    detect_indices = {
        col: cols_feat.index(col)
        for col in FEATURES_DETECT
        if col in cols_feat
    }

    resultats = []

    for i in range(len(meta)):
        client = meta.iloc[i]['numero_benef']
        aff_id = meta.iloc[i].get('affiliation_id', '')
        cat    = meta.iloc[i].get('code_payment_agregator', '')
        n_mois = int(meta.iloc[i]['n_mois'])

        real_idx = np.where(masks_np[i] == 1)[0]
        if len(real_idx) == 0:
            continue

        df_client = df_orig[
            df_orig['numero_benef'].astype(str) == str(client)
        ].sort_values('time_idx').tail(n_mois)

        for k, t_idx in enumerate(real_idx):
            if k >= len(df_client):
                continue

            row_orig = df_client.iloc[k]

            is_agg = float(row_orig.get('is_aggregated', 0))
            if is_agg == 1:
                continue

            vars_anomalie = []
            score_max     = 0.0

            for col, j in detect_indices.items():
                err   = float(all_errors[i, t_idx, j])
                seuil = thresholds.get(col, 9999)

                if err > seuil:
                    score_norm = round(min(err / (seuil + 1e-8), 1.0), 4)
                    vars_anomalie.append(col)
                    score_max = max(score_max, score_norm)

            if vars_anomalie:
                mois  = str(row_orig.get('mois', '')).zfill(2)
                annee = str(row_orig.get('annee', ''))
                resultats.append({
                    'numero_benef'          : client,
                    'affiliation_id'        : aff_id,
                    'variable_anomalie'     : ', '.join(vars_anomalie),
                    'start_date'            : f"01/{mois}/{annee}",
                    'code_payment_agregator': cat,
                    'score_erreur'          : score_max,
                })

    df_res = pd.DataFrame(resultats)

    if not df_res.empty:
        df_res = df_res.sort_values(
            'score_erreur', ascending=False
        ).reset_index(drop=True)

    print(f"\nPhase={phase} | Anomalies={len(df_res)} | "
          f"Clients={df_res['numero_benef'].nunique() if not df_res.empty else 0}")

    return df_res


def run_lstm_ae_pipeline(data: pd.DataFrame) -> pd.DataFrame:

    print("\n" + "="*60)
    print("LSTM AUTOENCODER - DETECTION ANOMALIES PENSIONS")
    print("="*60)

    data = data.copy()
    data['numero_benef']           = data['numero_benef'].astype(str)
    data['annee']                  = data['annee'].astype(int)
    data['mois']                   = data['mois'].astype(int)
    data['code_payment_agregator'] = data['code_payment_agregator'].astype(str)

    df_train, df_val, df_test = split_clients(data)
    scalers = fit_scalers(df_train)

    print(f"\nConstruction sequences train...")
    seq_train, mask_train, meta_train, cols_feat = build_sequences(df_train, scalers)

    print(f"\nConstruction sequences val...")
    seq_val, mask_val, meta_val, _ = build_sequences(df_val, scalers)

    print(f"\nConstruction sequences test...")
    seq_test, mask_test, meta_test, _ = build_sequences(df_test, scalers)

    train_ds     = SequenceDataset(seq_train, mask_train)
    val_ds       = SequenceDataset(seq_val,   mask_val)
    train_loader = DataLoader(train_ds, batch_size=256, shuffle=True,  num_workers=0)
    val_loader   = DataLoader(val_ds,   batch_size=256, shuffle=False, num_workers=0)

    model = LSTMAutoEncoder(
        n_features  = len(cols_feat),
        hidden_size = 64,
        latent_size = 32,
        n_layers    = 2,
        dropout     = 0.1,
    ).to(DEVICE)

    model = train_lstm_ae(
        model        = model,
        train_loader = train_loader,
        val_loader   = val_loader,
        n_epochs     = 100,
        lr           = 0.001,
        patience     = 5,
    )

    print(f"\nCalcul seuils sur train...")
    thresholds = compute_thresholds(model, seq_train, mask_train, cols_feat)

    print(f"\n{'='*60}")
    print(f"DETECTION TEST - clients jamais vus")
    print(f"{'='*60}")

    df_anomalies = detect_anomalies(
        model      = model,
        sequences  = seq_test,
        masks      = mask_test,
        meta       = meta_test,
        cols_feat  = cols_feat,
        thresholds = thresholds,
        scalers    = scalers,
        df_orig    = df_test,
        phase      = 'test'
    )

    print(f"\n{'='*60}")
    print(f"RAPPORT FINAL")
    print(f"{'='*60}")

    if not df_anomalies.empty:
        print(f"Total anomalies  : {len(df_anomalies)}")
        print(f"Clients suspects : {df_anomalies['numero_benef'].nunique()}")
        print(f"\nPar categorie :")
        print(df_anomalies.groupby('code_payment_agregator')['score_erreur'].count())
        print(f"\nPar variable :")
        print(df_anomalies.groupby('variable_anomalie')['score_erreur'].count())
        print(f"\nTop 20 anomalies :")
        print(df_anomalies[[
            'numero_benef', 'affiliation_id',
            'variable_anomalie', 'start_date',
            'code_payment_agregator', 'score_erreur'
        ]].head(20).to_string(index=False))

        df_anomalies[[
            'numero_benef', 'affiliation_id',
            'variable_anomalie', 'start_date',
            'code_payment_agregator', 'score_erreur'
        ]].to_csv('lstm_ae_anomalies_test.csv', index=False, encoding='utf-8-sig')

        print(f"\nSauvegarde : lstm_ae_anomalies_test.csv")
    else:
        print("Aucune anomalie detectee")

    return df_anomalies