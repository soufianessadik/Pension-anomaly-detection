import pandas as pd
import numpy as np
import joblib
import os
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator, BayesianEstimator
from pgmpy.inference import VariableElimination
import warnings
warnings.filterwarnings('ignore')

# les variables cibles qu'on va analyser avec le réseau bayésien
TARGETS_RB = [
    'TOTAL_BRUT', 'TOTAL_MUTU', 'ir_9999',
    'TOTAL_CONT', 'TOTAL_PREL', 'af_20000'
]

N_BINS     = 4
CV_STABLE  = 0.15
SPIKE_MULT = 1.5

# seuils au-delà desquels on force la confirmation d'anomalie
# chaque variable a son propre seuil car les ordres de grandeur sont différents
SEUIL_FORCE = {
    'TOTAL_BRUT' : 50.0,
    'TOTAL_MUTU' : 1500.0,
    'ir_9999'    : 1500.0,
    'TOTAL_CONT' : 150.0,
    'TOTAL_PREL' : 1500.0,
    'af_20000'   : 1500.0,
}

# seuils de normalisation séparés de SEUIL_FORCE
# pour MUTU : 200% max car disparition = 100% et spike x2 = 100%
SEUIL_NORM = {
    'TOTAL_BRUT' : 50.0,
    'TOTAL_MUTU' : 200.0,
    'ir_9999'    : 1500.0,
    'TOTAL_CONT' : 150.0,
    'TOTAL_PREL' : 1500.0,
    'af_20000'   : 50.0,
}

SCORE_FINAL_MIN = 0.30

MODELS_PATH = 'models/rb_models.pkl'
os.makedirs('models', exist_ok=True)

_MODELS_RB = {}


# vérifie si une série temporelle est stable (peu de variation)
# pour MUTU c'est différent : même avec peu de valeurs on analyse quand même
# car une disparition ou apparition soudaine est une anomalie métier
def is_serie_stable(series: np.ndarray,
                    cv_seuil : float = CV_STABLE,
                    var_name : str   = '') -> bool:
    non_zero = series[series > 0]
    if var_name == 'TOTAL_MUTU':
        if len(non_zero) == 0:
            return True   # jamais eu de MUTU -> stable, pas d'anomalie
        return False      # a eu MUTU -> on analyse toujours
    if len(non_zero) < 3:
        return True
    cv = non_zero.std() / (non_zero.mean() + 1e-8)
    return cv < cv_seuil


# détecte les mois anormaux pour une variable donnée
# on gère 3 types de spike : disparition, apparition, et spike classique
def detect_spike_mois(series   : np.ndarray,
                      var_name : str) -> np.ndarray:
    n           = len(series)
    ecarts      = np.zeros(n)
    vals_normal = series[series > 0]
    mediane     = np.median(vals_normal) if len(vals_normal) > 0 else 0.0
    iqr         = (np.percentile(vals_normal, 75) - np.percentile(vals_normal, 25)) \
                  if len(vals_normal) >= 2 else 0.0
    seuil_force = SEUIL_FORCE.get(var_name, 1000.0)
    is_mutu     = (var_name == 'TOTAL_MUTU')

    for t in range(n):
        val = series[t]

        # type 1 : la valeur disparaît (passe à 0) alors qu'elle était là avant
        if val == 0 and mediane > 0 and is_mutu:
            voisins_pos = []
            if t > 0 and series[t-1] > 0:     voisins_pos.append(series[t-1])
            if t < n-1 and series[t+1] > 0:   voisins_pos.append(series[t+1])
            if voisins_pos:
                ecarts[t] = 100.0  # on met 100% d'écart pour signaler la disparition
            continue

        if val == 0:
            continue

        # type 2 : la valeur apparaît alors qu'elle n'existait pas avant
        if mediane == 0 and val > 0 and is_mutu:
            ecarts[t] = 100.0
            continue

        # type 3 : spike classique - valeur anormalement haute ou basse
        if mediane <= 0:
            continue

        ecart_pct = abs(val - mediane) / mediane * 100
        z_score   = abs(val - mediane) / (iqr + 1e-8) \
                    if iqr > 0 else \
                    abs(val - mediane) / (mediane * 0.1 + 1e-8)
        is_spike  = (
            (z_score > 3.0 and val > SPIKE_MULT * mediane) or
            ecart_pct > seuil_force
        )
        if is_spike:
            # on vérifie que les voisins confirment le spike (pas juste du bruit)
            voisins = []
            if t > 0:     voisins.append(series[t-1])
            if t < n - 1: voisins.append(series[t+1])
            if voisins:
                mean_v = np.mean([v for v in voisins if v > 0])
                if mean_v > 0 and abs(val - mean_v) / mean_v * 100 > 20:
                    ecarts[t] = ecart_pct
            else:
                ecarts[t] = ecart_pct
    return ecarts


# discrétise une série continue en bins pour le réseau bayésien
# on utilise les quartiles pour définir les seuils de chaque bin
def discretiser(series: np.ndarray, n_bins: int = N_BINS) -> np.ndarray:
    result   = np.zeros(len(series), dtype=int)
    non_zero = series[series > 0]
    if len(non_zero) < n_bins:
        for i, v in enumerate(series):
            result[i] = 1 if v > 0 else 0
        return result
    quantiles = np.percentile(non_zero, [25, 50, 75])
    for i, v in enumerate(series):
        if   v == 0:              result[i] = 0
        elif v <= quantiles[0]:   result[i] = 1
        elif v <= quantiles[1]:   result[i] = 2
        elif v <= quantiles[2]:   result[i] = 3
        else:                     result[i] = 4
    return result


# discrétise les deltas (variations) en 5 catégories :
# forte baisse, baisse, stable, hausse, forte hausse
def discretiser_delta(delta: np.ndarray) -> np.ndarray:
    result  = np.full(len(delta), 2, dtype=int)
    pos     = delta[delta > 0]
    neg     = delta[delta < 0]
    p75_pos = np.percentile(pos, 75) if len(pos) > 0 else 1e9
    p25_neg = np.percentile(neg, 25) if len(neg) > 0 else -1e9
    for i, d in enumerate(delta):
        if abs(d) < 1e-6:  result[i] = 2
        elif d > 0:        result[i] = 4 if d >= p75_pos else 3
        else:              result[i] = 0 if d <= p25_neg else 1
    return result


def compute_delta(series: np.ndarray) -> np.ndarray:
    delta     = np.zeros(len(series))
    delta[1:] = series[1:] - series[:-1]
    return delta


# prépare les données pour l'entraînement du RB
# pour chaque client on calcule les features discrètes et les écarts
def prepare_rb_data(df_all   : pd.DataFrame,
                    var_name : str) -> pd.DataFrame:
    rows = []
    for (client, cat), df_c in df_all.groupby(
        ['numero_benef', 'code_payment_agregator']
    ):
        df_c = df_c.sort_values('time_idx')

        # on ignore les mois agrégés
        if 'is_aggregated' in df_c.columns:
            df_c = df_c[df_c['is_aggregated'] == 0]
        if df_c.empty:
            continue

        series_var = df_c[var_name].fillna(0).values
        delta_var  = compute_delta(series_var)
        disc_var   = discretiser(series_var)
        delta_disc = discretiser_delta(delta_var)
        ecarts_var = detect_spike_mois(series_var, var_name)

        # variables contextuelles selon la variable cible
        brut_disc = discretiser(df_c['TOTAL_BRUT'].fillna(0).values) \
                    if 'TOTAL_BRUT' in df_c.columns else None
        mutu_disc = discretiser(df_c['TOTAL_MUTU'].fillna(0).values) \
                    if 'TOTAL_MUTU' in df_c.columns else None
        cont_disc = discretiser(df_c['TOTAL_CONT'].fillna(0).values) \
                    if 'TOTAL_CONT' in df_c.columns else None
        prel_disc = discretiser(df_c['TOTAL_PREL'].fillna(0).values) \
                    if 'TOTAL_PREL' in df_c.columns else None

        for t in range(len(series_var)):
            r = {
                'CAT_PAIEMENT': str(cat),
                'VAR_disc'    : int(disc_var[t]),
                'DELTA_disc'  : int(delta_disc[t]),
                'ecart_pct'   : float(ecarts_var[t]),
                'ANOMALIE'    : int(ecarts_var[t] > 0),
            }
            # les parents du DAG varient selon la variable analysée
            if var_name == 'ir_9999':
                r['BRUT_disc'] = int(brut_disc[t]) if brut_disc is not None else 0
                r['MUTU_disc'] = int(mutu_disc[t]) if mutu_disc is not None else 0
                r['CONT_disc'] = int(cont_disc[t]) if cont_disc is not None else 0
                r['PREL_disc'] = int(prel_disc[t]) if prel_disc is not None else 0
            elif var_name == 'TOTAL_PREL':
                r['BRUT_disc'] = int(brut_disc[t]) if brut_disc is not None else 0
            rows.append(r)
    return pd.DataFrame(rows)


# définit la structure du DAG selon la variable
# chaque variable a ses propres dépendances causales
def get_dag_edges(var_name: str, df_rb: pd.DataFrame) -> list:
    edges = [('VAR_disc', 'ANOMALIE'), ('DELTA_disc', 'ANOMALIE')]
    if var_name == 'TOTAL_BRUT':
        edges += [('CAT_PAIEMENT', 'VAR_disc'), ('CAT_PAIEMENT', 'ANOMALIE')]
    elif var_name == 'TOTAL_MUTU':
        pass  # DAG simple : VAR_disc + DELTA_disc -> ANOMALIE
    elif var_name == 'ir_9999':
        edges += [
            ('BRUT_disc', 'VAR_disc'), ('MUTU_disc', 'VAR_disc'),
            ('CONT_disc', 'VAR_disc'), ('PREL_disc', 'VAR_disc'),
            ('BRUT_disc', 'ANOMALIE'), ('MUTU_disc', 'ANOMALIE'),
            ('CONT_disc', 'ANOMALIE'), ('PREL_disc', 'ANOMALIE'),
        ]
    elif var_name == 'TOTAL_PREL':
        edges += [('BRUT_disc', 'VAR_disc'), ('BRUT_disc', 'ANOMALIE')]
    elif var_name == 'af_20000':
        edges += [('CAT_PAIEMENT', 'ANOMALIE')]
    return list(set(edges))


# entraîne le réseau bayésien pour une variable
# on essaie MLE d'abord, puis BayesianEstimator si ça plante
def build_and_train_rb(df_all   : pd.DataFrame,
                       var_name : str) -> tuple:
    df_rb = prepare_rb_data(df_all, var_name)
    df_rb = df_rb.drop(columns=['ecart_pct'])
    if len(df_rb) < 10:
        return None, None
    edges        = get_dag_edges(var_name, df_rb)
    nodes_needed = set(n for e in edges for n in e)
    cols_ok      = [c for c in nodes_needed if c in df_rb.columns]
    df_rb        = df_rb[cols_ok].copy()
    edges_valid  = [(a, b) for a, b in edges
                    if a in df_rb.columns and b in df_rb.columns]
    if not edges_valid:
        return None, None
    model = BayesianNetwork(edges_valid)
    try:
        model.fit(df_rb, estimator=MaximumLikelihoodEstimator)
    except Exception:
        try:
            model.fit(df_rb, estimator=BayesianEstimator,
                      prior_type='BDeu', equivalent_sample_size=5)
        except Exception as e:
            print(f"  Warning {var_name} : {e}")
            return None, None
    return model, VariableElimination(model)


# cache pour éviter de refaire les mêmes inférences plusieurs fois
# ça accélère beaucoup quand on a des milliers de clients
_INFERENCE_CACHE = {}


def _query_cached(inference, evidence_valid):
    cache_key = tuple(sorted(
        (k, str(v)) for k, v in evidence_valid.items()
    ))
    if cache_key in _INFERENCE_CACHE:
        return _INFERENCE_CACHE[cache_key]
    try:
        query  = inference.query(['ANOMALIE'], evidence=evidence_valid,
                                 show_progress=False)
        p_anom = float(query.values[1])
    except Exception:
        p_anom = 0.0
    _INFERENCE_CACHE[cache_key] = p_anom
    return p_anom


# fait l'inférence mois par mois pour un client et une variable donnée
# retourne la probabilité d'anomalie et le score final pour chaque mois
def inference_client_var(df_client : pd.DataFrame,
                         var_name  : str,
                         inference : VariableElimination,
                         cat       : str = None) -> pd.DataFrame:
    if cat is not None and 'code_payment_agregator' in df_client.columns:
        df_prep = df_client[
            df_client['code_payment_agregator'] == cat
        ].sort_values('time_idx').copy()
    else:
        df_prep = df_client.sort_values('time_idx').copy()

    if 'is_aggregated' in df_prep.columns:
        df_prep = df_prep[df_prep['is_aggregated'] == 0]

    if df_prep.empty:
        return pd.DataFrame()

    series    = df_prep[var_name].fillna(0).values
    delta     = compute_delta(series)
    disc      = discretiser(series)
    d_disc    = discretiser_delta(delta)
    ecarts    = detect_spike_mois(series, var_name)

    brut_disc = discretiser(df_prep['TOTAL_BRUT'].fillna(0).values) \
                if 'TOTAL_BRUT' in df_prep.columns else None
    mutu_disc = discretiser(df_prep['TOTAL_MUTU'].fillna(0).values) \
                if 'TOTAL_MUTU' in df_prep.columns else None
    cont_disc = discretiser(df_prep['TOTAL_CONT'].fillna(0).values) \
                if 'TOTAL_CONT' in df_prep.columns else None
    prel_disc = discretiser(df_prep['TOTAL_PREL'].fillna(0).values) \
                if 'TOTAL_PREL' in df_prep.columns else None
    cat_val   = str(df_prep['code_payment_agregator'].iloc[0]) \
                if 'code_payment_agregator' in df_prep.columns else 'UNK'

    seuil_force = SEUIL_FORCE.get(var_name, 1000.0)
    seuil_norm  = SEUIL_NORM.get(var_name, 1000.0)
    model_nodes = set(inference.model.nodes())
    resultats   = []

    for t in range(len(series)):
        # optimisation perf : on skip les mois sans anomalie détectée
        # sauf pour MUTU où on veut quand même vérifier les disparitions
        if ecarts[t] == 0 and var_name != 'TOTAL_MUTU':
            row_t = df_prep.iloc[t]
            mois  = str(row_t.get('mois', '')).zfill(2)
            annee = str(row_t.get('annee', ''))
            resultats.append({
                'time_idx'   : int(row_t['time_idx']),
                'start_date' : f"01/{mois}/{annee}",
                'val_reelle' : float(series[t]),
                'ecart_pct'  : 0.0,
                'is_spike'   : 0,
                'p_anomalie' : 0.0,
                'score_final': 0.0,
            })
            continue

        # on construit l'évidence selon la variable
        evidence = {'VAR_disc': int(disc[t]), 'DELTA_disc': int(d_disc[t])}
        if var_name == 'TOTAL_BRUT':
            evidence['CAT_PAIEMENT'] = cat_val
        elif var_name == 'TOTAL_MUTU':
            pass  # DAG simple, pas de parents supplémentaires
        elif var_name == 'ir_9999':
            if brut_disc is not None: evidence['BRUT_disc'] = int(brut_disc[t])
            if mutu_disc is not None: evidence['MUTU_disc'] = int(mutu_disc[t])
            if cont_disc is not None: evidence['CONT_disc'] = int(cont_disc[t])
            if prel_disc is not None: evidence['PREL_disc'] = int(prel_disc[t])
        elif var_name == 'TOTAL_PREL':
            if brut_disc is not None: evidence['BRUT_disc'] = int(brut_disc[t])
        elif var_name == 'af_20000':
            evidence['CAT_PAIEMENT'] = cat_val

        # on garde seulement les noeuds présents dans le modèle
        evidence_valid = {k: v for k, v in evidence.items()
                          if k in model_nodes}

        p_anom = _query_cached(inference, evidence_valid)

        # si l'écart est très grand on force une proba élevée
        if ecarts[t] > seuil_force:
            p_anom = max(p_anom, 0.95)

        # normalisation sur SEUIL_NORM (pas SEUIL_FORCE) pour éviter écrasement MUTU
        ecart_ratio = min(ecarts[t] / (seuil_norm + 1e-8), 1.0)

        score_final = round(p_anom * ecart_ratio, 4)
        row_t       = df_prep.iloc[t]
        mois        = str(row_t.get('mois', '')).zfill(2)
        annee       = str(row_t.get('annee', ''))

        resultats.append({
            'time_idx'   : int(row_t['time_idx']),
            'start_date' : f"01/{mois}/{annee}",
            'val_reelle' : float(series[t]),
            'ecart_pct'  : float(ecarts[t]),
            'is_spike'   : int(ecarts[t] > 0),
            'p_anomalie' : round(p_anom, 4),
            'score_final': score_final,
        })
    return pd.DataFrame(resultats)


# seuil adaptatif calculé à partir de la distribution des probabilités du client
# ça évite d'avoir un seuil fixe qui marche pas pour tous les clients
def get_seuil_adaptatif(df_inf    : pd.DataFrame,
                        seuil_min : float = 0.45,
                        seuil_max : float = 0.80) -> float:
    if df_inf.empty or len(df_inf) < 3:
        return 0.65
    p = df_inf['p_anomalie'].values
    return float(np.clip(p.mean() + 2.5 * p.std(), seuil_min, seuil_max))


def get_niveau_label(score: float) -> str:
    if   score <= 0.00: return 'Normal'
    elif score <= 0.40: return 'Faible'
    elif score <= 0.70: return 'Modere'
    else:               return 'Eleve'


# entraîne un RB pour chaque variable cible
# on sauvegarde tous les modèles dans un fichier pkl
def train_rb(df_complet: pd.DataFrame) -> dict:
    global _MODELS_RB

    df_complet['numero_benef'] = df_complet['numero_benef'].astype(str)
    print(f"\nEntrainement RB par variable...", flush=True)

    models_rb = {}
    for var in TARGETS_RB:
        if var not in df_complet.columns:
            continue
        print(f"  {var}...", flush=True)
        _, inf = build_and_train_rb(df_complet, var)
        if inf is not None:
            models_rb[var] = inf
            print(f"  {var} OK", flush=True)
        else:
            print(f"  {var} ECHEC", flush=True)

    print(f"\nRB entraînés : {len(models_rb)}/{len(TARGETS_RB)}", flush=True)

    joblib.dump(models_rb, MODELS_PATH)
    print(f"Modeles sauvegardes : {MODELS_PATH}", flush=True)

    _MODELS_RB = models_rb
    return models_rb


# fait tourner l'inférence sur tous les clients suspects détectés par le LSTM
# on indexe df_complet pour aller beaucoup plus vite (O(log n) au lieu de O(n))
def run_rb_inference(df_complet       : pd.DataFrame,
                     df_lstm_suspects : pd.DataFrame,
                     models_rb        : dict = None) -> pd.DataFrame:
    global _MODELS_RB

    if models_rb is None: models_rb = _MODELS_RB

    if not models_rb:
        print("ERREUR : modèles RB non entraînés.", flush=True)
        return pd.DataFrame()

    df_complet['numero_benef'] = df_complet['numero_benef'].astype(str)

    df_lstm_suspects = df_lstm_suspects.drop_duplicates(
        subset=['numero_benef', 'variable_anomalie',
                'start_date', 'code_payment_agregator']
    ).reset_index(drop=True)

    n_suspects = df_lstm_suspects['numero_benef'].nunique()
    n_lignes   = len(df_lstm_suspects)
    print(f"\nInférence sur {n_suspects} clients "
          f"({n_lignes} lignes)...", flush=True)

    # indexation par client pour éviter des scans complets à chaque itération
    print("Indexation df_complet...", flush=True)
    df_complet_idx = df_complet.set_index('numero_benef', drop=False).sort_index()
    print("Indexation terminée.", flush=True)

    confirmations = {}
    meta_client   = {}

    global _INFERENCE_CACHE
    _INFERENCE_CACHE = {}

    for i, row_s in enumerate(df_lstm_suspects.itertuples(), 1):
        if i % 500 == 0:
            print(f"  {i}/{n_lignes}... (cache: {len(_INFERENCE_CACHE)} entrées)",
                  flush=True)

        client      = str(row_s.numero_benef)
        vars_det    = str(row_s.variable_anomalie).split(', ')
        cat_suspect = str(row_s.code_payment_agregator) \
                      if hasattr(row_s, 'code_payment_agregator') else None
        start_date  = str(row_s.start_date) \
                      if hasattr(row_s, 'start_date') else ''

        # lookup rapide par index
        try:
            df_client = df_complet_idx.loc[[client]].copy()
        except KeyError:
            continue

        if df_client.empty:
            continue

        aff_id = str(df_client['affiliation_id'].iloc[0]) \
                 if 'affiliation_id' in df_client.columns else ''
        meta_client[client] = {'aff_id': aff_id}

        for var in vars_det:
            var = var.strip()
            if var not in TARGETS_RB or models_rb.get(var) is None:
                continue
            if var not in df_client.columns:
                continue

            df_client_cat = df_client[
                df_client['code_payment_agregator'] == cat_suspect
            ].copy() if cat_suspect else df_client.copy()

            if df_client_cat.empty:
                continue

            series = df_client_cat[var].fillna(0).values
            if is_serie_stable(series, var_name=var):
                continue

            df_inf = inference_client_var(
                df_client_cat, var,
                models_rb[var],
                cat=cat_suspect
            )

            if df_inf.empty:
                continue

            seuil = get_seuil_adaptatif(df_inf)

            # pour MUTU on inclut aussi les disparitions (is_spike peut être 0)
            if var == 'TOTAL_MUTU':
                df_conf = df_inf[
                    (df_inf['p_anomalie']  > seuil) &
                    (df_inf['ecart_pct']   > 0)     &
                    (df_inf['score_final'] >= SCORE_FINAL_MIN)
                ].copy()
            else:
                df_conf = df_inf[
                    (df_inf['p_anomalie']  > seuil) &
                    (df_inf['is_spike']    == 1)    &
                    (df_inf['score_final'] >= SCORE_FINAL_MIN)
                ].copy()

            if df_conf.empty:
                continue

            # on garde le meilleur score par mois et par variable
            for _, r in df_conf.iterrows():
                key = (client, r['start_date'], cat_suspect)
                if key not in confirmations:
                    confirmations[key] = {}
                if var not in confirmations[key] or \
                   r['score_final'] > confirmations[key][var]['score_final']:
                    confirmations[key][var] = {
                        'score_final' : r['score_final'],
                        'p_anomalie'  : r['p_anomalie'],
                        'ecart_pct'   : r['ecart_pct'],
                        'val_reelle'  : r['val_reelle'],
                        'seuil'       : round(seuil, 4),
                    }

    # construction du dataframe de résultats final
    resultats = []
    for (client, start_date, cat), vars_info in confirmations.items():
        if not vars_info:
            continue

        aff_id       = meta_client.get(client, {}).get('aff_id', '')
        vars_sorted  = sorted(vars_info.items(),
                              key=lambda x: x[1]['score_final'],
                              reverse=True)
        score_mois   = max(v['score_final'] for v in vars_info.values())
        p_mois       = max(v['p_anomalie']  for v in vars_info.values())
        seuil_mois   = vars_sorted[0][1]['seuil']
        vars_liste   = ', '.join([v[0] for v in vars_sorted])
        detail_ecart = {v: round(info['ecart_pct'], 2)
                        for v, info in vars_info.items()}
        detail_val   = {v: round(info['val_reelle'], 2)
                        for v, info in vars_info.items()}

        resultats.append({
            'numero_benef'          : client,
            'affiliation_id'        : aff_id,
            'variable_anomalie'     : vars_liste,
            'start_date'            : start_date,
            'code_payment_agregator': cat,
            'score_final'           : round(score_mois, 4),
            'p_anomalie'            : round(p_mois, 4),
            'seuil_adaptatif'       : seuil_mois,
            'niveau_label'          : get_niveau_label(score_mois),
            'detail_ecart_pct'      : str(detail_ecart),
            'detail_val_reelle'     : str(detail_val),
            'anomalie_confirmee'    : True,
        })

    df_res = pd.DataFrame(resultats)

    if df_res.empty:
        print("Aucune anomalie confirmee", flush=True)
        return df_res

    df_res = df_res.sort_values(
        'score_final', ascending=False
    ).reset_index(drop=True)

    print(f"\n{'='*60}", flush=True)
    print(f"RAPPORT FINAL RB", flush=True)
    print(f"{'='*60}", flush=True)
    print(f"Total lignes     : {len(df_res)}", flush=True)
    print(f"Clients confirms : {df_res['numero_benef'].nunique()}", flush=True)
    print(f"\nPar categorie :", flush=True)
    print(df_res.groupby('code_payment_agregator')['score_final'].count())
    print(f"\nPar variable :", flush=True)
    print(df_res.groupby('variable_anomalie')['score_final'].count().head(20))
    print(f"\nPar niveau :", flush=True)
    print(df_res.groupby('niveau_label')['score_final'].count())
    print(f"\nDistribution scores :", flush=True)
    print(df_res['score_final'].describe())
    print(f"\nTop 20 anomalies :", flush=True)
    print(df_res[[
        'numero_benef', 'affiliation_id',
        'variable_anomalie', 'start_date',
        'code_payment_agregator', 'score_final', 'niveau_label'
    ]].head(20).to_string(index=False))

    df_res.to_csv('rb_anomalies_confirmes.csv',
                  index=False, encoding='utf-8-sig')
    print(f"\nSauvegarde : rb_anomalies_confirmes.csv", flush=True)

    return df_res


# charge les modèles sauvegardés si on veut relancer l'inférence sans réentraîner
def load_rb_models() -> dict:
    models_rb = joblib.load(MODELS_PATH)
    global _MODELS_RB
    _MODELS_RB = models_rb
    print(f"Modeles charges : {len(models_rb)} RB", flush=True)
    return models_rb


# pipeline complet : entraînement puis inférence
def run_rb_pipeline(df_complet       : pd.DataFrame,
                    df_lstm_suspects : pd.DataFrame) -> tuple:
    print("\n" + "="*60, flush=True)
    print("RESEAU BAYESIEN - CONFIRMATION ANOMALIES", flush=True)
    print("="*60, flush=True)

    models_rb = train_rb(df_complet)
    df_res    = run_rb_inference(df_complet, df_lstm_suspects, models_rb)
    return df_res, models_rb


