import pandas as pd
import numpy as np
import gc
import logging
from pandas.tseries.offsets import MonthEnd

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

DATA_PATH   = 'data/data.parquet'
OUTPUT_PATH = 'data/df_preprocessed.parquet'

# colonnes qu'on garde pour LSTM + RB
COLS_Model = [
    'affiliation_id', 'numero_benef', 'beneficiary',
    'annee', 'mois', 'trimestre', 'time_idx',
    'clients_per_doc', 'code_payment_agregator',
    'TOTAL_BRUT', 'TOTAL_MUTU', 'Ratio_Mutu',
    'TOTAL_CONT', 'Ratio_cont', 'TOTAL_PREL', 'Ratio_prel',
    'ir_9999', 'Ratio_ir', 'TOTAL_REMB', 'af_20000',
    'abat_6666', 'net_100',
    'is_aggregated',
]


COLS_SUM = [
    'TOTAL_BRUT', 'TOTAL_MUTU', 'TOTAL_CONT',
    'TOTAL_PREL', 'TOTAL_REMB', 'ir_9999',
    'af_20000', 'abat_6666', 'net_100',
]


# chargement du parquet et conversion des types pour économiser la mémoire
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_parquet(path, engine='pyarrow')

    float_cols = df.select_dtypes(include='float64').columns
    df[float_cols] = df[float_cols].astype('float32')

    int_cols = df.select_dtypes(include='int64').columns
    df[int_cols] = df[int_cols].astype('int32')

    gc.collect()
    logger.info(f"Shape : {df.shape}")
    logger.info(f"Memoire : {df.memory_usage(deep=True).sum() / 1e9:.2f} GB")
    return df


# conversion des colonnes de dates en datetime
def convert_dates(df: pd.DataFrame) -> pd.DataFrame:
    for col in ['term', 'start_date', 'end_date']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], format='%Y-%m-%d', errors='coerce')
            n_nat = df[col].isna().sum()
            if n_nat > 0:
                logger.warning(f"{col} : {n_nat} valeurs NaT")
    return df


# remplacement des NaN par 0 sur toutes les colonnes numériques
def fill_nan(df: pd.DataFrame) -> pd.DataFrame:
    float_cols = df.select_dtypes(include=['float64', 'float32']).columns
    df[float_cols] = df[float_cols].fillna(0)
    logger.info(f"NaN remplaces sur {len(float_cols)} colonnes numeriques")
    return df


# calcul des totaux agrégés et des ratios + extraction mois/annee/trimestre
def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    for keyword, col in [
        ('brut', 'TOTAL_BRUT'),
        ('mutu', 'TOTAL_MUTU'),
        ('cont', 'TOTAL_CONT'),
        ('prel', 'TOTAL_PREL'),
        ('remb', 'TOTAL_REMB')
    ]:
        cols_kw = [c for c in df.columns if keyword in c.lower()]
        df[col] = df[cols_kw].sum(axis=1)
        del cols_kw
        gc.collect()

    df['Ratio_Mutu'] = np.where(df['TOTAL_BRUT'] == 0, 0, (df['TOTAL_MUTU'] / df['TOTAL_BRUT']) * 100)
    df['Ratio_cont'] = np.where(df['TOTAL_BRUT'] == 0, 0, (df['TOTAL_CONT'] / df['TOTAL_BRUT']) * 100)
    df['Ratio_prel'] = np.where(df['TOTAL_BRUT'] == 0, 0, (df['TOTAL_PREL'] / df['TOTAL_BRUT']) * 100)
    df['Ratio_ir']   = np.where(df['TOTAL_BRUT'] == 0, 0, (df['ir_9999']    / df['TOTAL_BRUT']) * 100)
    gc.collect()

    if 'start_date' not in df.columns:
        raise ValueError("Colonne start_date manquante")

    df['mois']      = df['start_date'].dt.month
    df['annee']     = df['start_date'].dt.year
    df['trimestre'] = df['start_date'].dt.quarter

    gc.collect()
    return df


# agrégation mensuelle par client et catégorie
# is_aggregated=1 si le client avait plusieurs lignes dans le même mois
def aggregate_monthly(df: pd.DataFrame) -> pd.DataFrame:

    clients_avant = set(df['numero_benef'].unique())

    df['_jour']  = df['start_date'].dt.day
    df['_count'] = df.groupby(
        ['numero_benef', 'code_payment_agregator', 'annee', 'mois']
    )['_jour'].transform('count')

    df['is_aggregated'] = (
        (df['_count'] > 1) | (df['_jour'] != 1)
    ).astype(int)

    cols_ratio   = ['Ratio_Mutu', 'Ratio_cont', 'Ratio_prel', 'Ratio_ir']
    cols_non_fin = [
        c for c in df.columns
        if c not in COLS_SUM
        and c not in cols_ratio
        and c not in [
            '_jour', '_count',
            'annee', 'mois',
            'numero_benef', 'code_payment_agregator',
            'start_date', 'is_aggregated'
        ]
    ]

    agg_dict = {}
    for col in COLS_SUM:
        if col in df.columns:
            agg_dict[col] = 'sum'
    for col in cols_non_fin:
        if col in df.columns:
            agg_dict[col] = 'first'
    agg_dict['is_aggregated'] = 'max'

    df_agg = df.groupby(
        ['numero_benef', 'code_payment_agregator', 'annee', 'mois'],
        as_index=False
    ).agg(agg_dict)

    df_agg['start_date'] = pd.to_datetime(
        df_agg['annee'].astype(str) + '-' +
        df_agg['mois'].astype(str).str.zfill(2) + '-01'
    )

    df_agg['Ratio_Mutu'] = np.where(
        df_agg['TOTAL_BRUT'] == 0, 0,
        (df_agg['TOTAL_MUTU'] / df_agg['TOTAL_BRUT']) * 100
    )
    df_agg['Ratio_cont'] = np.where(
        df_agg['TOTAL_BRUT'] == 0, 0,
        (df_agg['TOTAL_CONT'] / df_agg['TOTAL_BRUT']) * 100
    )
    df_agg['Ratio_prel'] = np.where(
        df_agg['TOTAL_BRUT'] == 0, 0,
        (df_agg['TOTAL_PREL'] / df_agg['TOTAL_BRUT']) * 100
    )
    df_agg['Ratio_ir'] = np.where(
        df_agg['TOTAL_BRUT'] == 0, 0,
        (df_agg['ir_9999']   / df_agg['TOTAL_BRUT']) * 100
    )

    gc.collect()

    # vérification qu'on n'a perdu aucun client pendant l'agrégation
    clients_apres = set(df_agg['numero_benef'].unique())
    perdus        = clients_avant - clients_apres
    if perdus:
        logger.error(f"CLIENTS PERDUS : {len(perdus)} - {list(perdus)[:10]}")
        raise AssertionError(f"{len(perdus)} clients perdus après agrégation !")
    else:
        logger.info("Vérification clients OK - aucun client perdu")

    n_avant = len(df)
    n_apres = len(df_agg)
    n_agg   = df_agg['is_aggregated'].sum()
    logger.info(f"Agrégation : {n_avant} lignes -> {n_apres} lignes")
    logger.info(f"Lignes is_aggregated=1 : {n_agg} ({n_agg/n_apres*100:.1f}%)")

    return df_agg


# index temporel par client - utilisé par le LSTM pour ordonner les séquences
def compute_time_idx(df: pd.DataFrame) -> pd.DataFrame:
    df = df.sort_values(['numero_benef', 'code_payment_agregator', 'start_date'])
    df['time_idx'] = df.groupby(
        ['numero_benef', 'code_payment_agregator']
    )['start_date'].rank(method='dense').astype(int) - 1
    gc.collect()
    logger.info("time_idx calculé après agrégation")
    return df


# nombre de bénéficiaires par document d'affiliation
def compute_clients_per_doc(df: pd.DataFrame) -> pd.DataFrame:
    df['clients_per_doc'] = df.groupby(
        'affiliation_id'
    )['numero_benef'].transform('nunique')
    gc.collect()
    logger.info("clients_per_doc calculé après agrégation")
    return df


# garde uniquement les colonnes disponibles dans df
def select_columns(df: pd.DataFrame, cols: list) -> pd.DataFrame:
    cols_dispo      = [c for c in cols if c in df.columns]
    cols_manquantes = [c for c in cols if c not in df.columns]
    if cols_manquantes:
        logger.warning(f"Colonnes manquantes : {cols_manquantes}")
    return df[cols_dispo]


def save_data(df: pd.DataFrame, output_path: str) -> None:
    df.to_parquet(output_path, index=False, engine='pyarrow')
    logger.info(f"Sauvegarde : {output_path}")


def rapport(df: pd.DataFrame) -> None:
    print(f"\n{'='*60}")
    print(f"Shape                : {df.shape}")
    print(f"Memoire              : {df.memory_usage(deep=True).sum() / 1e9:.2f} GB")
    print(f"Clients uniques      : {df['numero_benef'].nunique()}")
    print(f"Categories           : {df['code_payment_agregator'].nunique()}")
    print(f"Periode              : {df['mois'].min()}/{df['annee'].min()} -> {df['mois'].max()}/{df['annee'].max()}")
    print(f"NaN restants         : {df.isna().sum().sum()}")
    print(f"is_aggregated=1      : {df['is_aggregated'].sum()} ({df['is_aggregated'].mean()*100:.1f}%)")
    print(f"time_idx max         : {df['time_idx'].max()}")
    print(f"{'='*60}\n")


# pipeline complet preprocessing
# retourne df_model pour LSTM+RB et df_original pour le drill-down
def run_preprocessing(
    data_path   = DATA_PATH,
    output_path = OUTPUT_PATH,
):
    # on garde df_original brut pour le drill-down
    df_original = load_data(data_path)
    gc.collect()

    df = df_original.copy()

    df = convert_dates(df)

    df = fill_nan(df)
    gc.collect()

    df = compute_features(df)
    gc.collect()

    df = aggregate_monthly(df)
    gc.collect()

    df = compute_time_idx(df)

    df = compute_clients_per_doc(df)
    gc.collect()

    rapport(df)

    df_model = select_columns(df, COLS_Model)

    save_data(df_model, output_path)
    logger.info(f"df_model    : {df_model.shape}")
    logger.info(f"df_original : {df_original.shape}")

    return df_model, df_original