import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import joblib
import importlib.util as _ilu
import warnings
from torch.utils.data import Dataset, DataLoader
warnings.filterwarnings('ignore')

# ----------------------------------------------------------------
# l'expert métier renseigne uniquement ces chemins
# ----------------------------------------------------------------
DATA_PATH          = 'data/data.parquet'   # données brutes .parquet
LSTM_MODEL_PATH    = 'models/lstm_ae_model.pt'
LSTM_SCALERS_PATH  = 'models/lstm_ae_scalers.pkl'
RB_MODELS_PATH     = 'models/rb_models.pkl'
RB_CODE_PATH       = 'src/RB_pipeline_final.py'
PREPROCESSING_PATH = 'src/Preprocessing.py'  # chemin vers Preprocessing.py

FEATURES_INPUT = [
    'TOTAL_BRUT', 'TOTAL_MUTU', 'ir_9999',
    'TOTAL_CONT', 'TOTAL_PREL', 'af_20000',
    'Ratio_Mutu', 'Ratio_cont', 'Ratio_prel', 'Ratio_ir',
]
FEATURES_DETECT = [
    'TOTAL_BRUT', 'TOTAL_MUTU', 'ir_9999',
    'TOTAL_CONT', 'TOTAL_PREL', 'af_20000',
]
MAX_LEN          = 17
SEUIL_PERCENTILE = 99

DEBUG = False


def get_device():
    try:
        if torch.cuda.is_available():
            t = torch.zeros(1).cuda()
            _ = t + t
            del t
            print(f"GPU : {torch.cuda.get_device_name(0)}")
            return torch.device('cuda')
    except Exception:
        pass
    print("CPU utilisé")
    return torch.device('cpu')

DEVICE = get_device()


class LSTMAutoEncoder(nn.Module):
    def __init__(self, n_features, hidden_size=64,
                 latent_size=32, n_layers=2, dropout=0.1):
        super().__init__()
        self.encoder    = nn.LSTM(
            input_size=n_features, hidden_size=hidden_size,
            num_layers=n_layers, batch_first=True,
            dropout=dropout if n_layers > 1 else 0,
        )
        self.encoder_fc = nn.Linear(hidden_size, latent_size)
        self.decoder_fc = nn.Linear(latent_size, hidden_size)
        self.decoder    = nn.LSTM(
            input_size=hidden_size, hidden_size=hidden_size,
            num_layers=n_layers, batch_first=True,
            dropout=dropout if n_layers > 1 else 0,
        )
        self.output_fc  = nn.Linear(hidden_size, n_features)

    def forward(self, x, mask=None):
        batch_size = x.size(0)
        seq_len    = x.size(1)
        enc_out, _ = self.encoder(x)
        if mask is not None:
            last_idx    = mask.long().sum(dim=1) - 1
            offset      = seq_len - mask.long().sum(dim=1)
            real_idx    = (offset + last_idx).clamp(0, seq_len - 1)
            last_hidden = enc_out[torch.arange(batch_size), real_idx]
        else:
            last_hidden = enc_out[:, -1, :]
        z          = torch.tanh(self.encoder_fc(last_hidden))
        dec_input  = torch.relu(self.decoder_fc(z))
        dec_input  = dec_input.unsqueeze(1).repeat(1, seq_len, 1)
        dec_out, _ = self.decoder(dec_input)
        return self.output_fc(dec_out)


class SequenceDataset(Dataset):
    def __init__(self, sequences, masks):
        self.sequences = torch.tensor(sequences, dtype=torch.float32)
        self.masks     = torch.tensor(masks,     dtype=torch.float32)
    def __len__(self):          return len(self.sequences)
    def __getitem__(self, idx): return self.sequences[idx], self.masks[idx]


def apply_scalers(df, scalers):
    df   = df.copy()
    cols = [c for c in FEATURES_INPUT if c in df.columns]
    for col in cols:
        if col not in scalers or scalers[col] is None:
            continue
        scaler  = scalers[col]
        vals    = df[col].values.copy().astype(float)
        mask_nz = vals > 0
        if mask_nz.sum() == 0:
            continue
        log_nz          = np.log1p(vals[mask_nz].reshape(-1, 1))
        scaled          = scaler.transform(log_nz).flatten()
        result          = np.zeros_like(vals, dtype=np.float32)
        result[mask_nz] = np.clip(scaled, -3, 3)
        df[col]         = result
    return df


def build_sequences_all(df, scalers, max_len=MAX_LEN):
    df        = apply_scalers(df, scalers)
    cols_feat = [c for c in FEATURES_INPUT if c in df.columns]

    df['_period'] = df['annee'].astype(int) * 100 + df['mois'].astype(int)
    df_window     = df[
        (df['_period'] >= 202501) & (df['_period'] <= 202605)
    ].copy()

    if df_window.empty:
        print("  Aucune donnée dans la fenêtre Jan2025->Mai2026")
        df_window = df.copy()

    df_window = df_window.sort_values(['numero_benef', 'time_idx'])
    sequences, masks, meta_rows = [], [], []
    grouped = df_window.groupby('numero_benef')
    total   = len(grouped)
    print(f"  {total} clients à traiter...")

    for idx, (client, df_c) in enumerate(grouped):
        if idx % 20000 == 0:
            print(f"  {idx}/{total} clients...")

        vals = df_c[cols_feat].fillna(0).values.astype(np.float32)
        T    = len(vals)
        if T > max_len:
            vals = vals[-max_len:]
            T    = max_len

        padded               = np.zeros((max_len, len(cols_feat)), dtype=np.float32)
        padded[max_len - T:] = vals
        mask                 = np.zeros(max_len, dtype=np.float32)
        mask[max_len - T:]   = 1.0

        sequences.append(padded)
        masks.append(mask)

        last_row = df_c.iloc[-1]
        meta_rows.append({
            'numero_benef'          : client,
            'affiliation_id'        : last_row.get('affiliation_id', ''),
            'code_payment_agregator': last_row.get('code_payment_agregator', ''),
            'mois'                  : last_row.get('mois', ''),
            'annee'                 : last_row.get('annee', ''),
            'n_mois'                : T,
        })

    sequences = np.array(sequences, dtype=np.float32)
    masks     = np.array(masks,     dtype=np.float32)
    meta      = pd.DataFrame(meta_rows)
    print(f"  Séquences : {sequences.shape}")
    return sequences, masks, meta, cols_feat


def compute_thresholds(model, sequences, masks, cols_feat,
                       percentile=SEUIL_PERCENTILE):
    model.eval()
    all_errors = {col: [] for col in cols_feat}
    loader     = DataLoader(
        SequenceDataset(sequences, masks),
        batch_size=512, shuffle=False
    )
    with torch.no_grad():
        for seqs_b, masks_b in loader:
            seqs_b  = seqs_b.to(DEVICE)
            masks_b = masks_b.to(DEVICE)
            recon_b = model(seqs_b, masks_b)
            error_b = (recon_b - seqs_b).abs().cpu().numpy()
            mask_np = masks_b.cpu().numpy()
            for b in range(error_b.shape[0]):
                real_idx = np.where(mask_np[b] == 1)[0]
                if len(real_idx) == 0:
                    continue
                for j, col in enumerate(cols_feat):
                    all_errors[col].extend(error_b[b, real_idx, j].tolist())

    thresholds = {}
    print(f"\nSeuils (P{percentile}) :")
    for col in cols_feat:
        if all_errors[col]:
            seuil           = np.percentile(all_errors[col], percentile)
            thresholds[col] = seuil
            print(f"  {col:<25} : {seuil:.6f}")
    return thresholds


def detect_anomalies(model, sequences, masks, meta,
                     cols_feat, thresholds, df_orig):
    model.eval()
    loader     = DataLoader(
        SequenceDataset(sequences, masks),
        batch_size=512, shuffle=False
    )
    all_errors = []
    with torch.no_grad():
        for seqs_b, masks_b in loader:
            seqs_b  = seqs_b.to(DEVICE)
            masks_b = masks_b.to(DEVICE)
            recon_b = model(seqs_b, masks_b)
            all_errors.append((recon_b - seqs_b).abs().cpu().numpy())

    all_errors     = np.concatenate(all_errors, axis=0)
    masks_np       = masks
    detect_indices = {
        col: cols_feat.index(col)
        for col in FEATURES_DETECT if col in cols_feat
    }

    df_orig = df_orig.copy()
    df_orig['numero_benef'] = df_orig['numero_benef'].astype(str)
    df_grouped = {
        client: grp.sort_values('time_idx').reset_index(drop=True)
        for client, grp in df_orig.groupby('numero_benef')
    }

    resultats = []
    total     = len(meta)

    for i in range(total):
        if i % 10000 == 0:
            print(f"  Détection : {i}/{total} clients...")

        client   = str(meta.iloc[i]['numero_benef'])
        aff_id   = str(meta.iloc[i].get('affiliation_id', ''))
        cat      = str(meta.iloc[i].get('code_payment_agregator', ''))
        n_mois   = int(meta.iloc[i]['n_mois'])
        real_idx = np.where(masks_np[i] == 1)[0]

        if len(real_idx) == 0 or client not in df_grouped:
            continue

        df_client = df_grouped[client].tail(n_mois).reset_index(drop=True)

        for k, t_idx in enumerate(real_idx):
            if k >= len(df_client):
                continue
            row_orig = df_client.iloc[k]
            if float(row_orig.get('is_aggregated', 0)) == 1:
                continue

            vars_anomalie = []
            score_max     = 0.0
            for col, j in detect_indices.items():
                err   = float(all_errors[i, t_idx, j])
                seuil = thresholds.get(col, 9999)
                if err > seuil:
                    score_norm = round(min(err / (seuil + 1e-8), 1.0), 4)
                    vars_anomalie.append(col)
                    score_max = max(score_max, score_norm)

            if vars_anomalie:
                mois  = str(row_orig.get('mois', '')).zfill(2)
                annee = str(row_orig.get('annee', ''))
                resultats.append({
                    'numero_benef'          : client,
                    'affiliation_id'        : aff_id,
                    'variable_anomalie'     : ', '.join(vars_anomalie),
                    'start_date'            : f"01/{mois}/{annee}",
                    'code_payment_agregator': cat,
                    'score_erreur'          : score_max,
                })

    df_res = pd.DataFrame(resultats)
    if not df_res.empty:
        df_res = df_res.sort_values(
            'score_erreur', ascending=False
        ).reset_index(drop=True)

    print(f"\nLSTM-AE | Anomalies={len(df_res)} | "
          f"Clients={df_res['numero_benef'].nunique() if not df_res.empty else 0}")
    return df_res


VAR_TO_PREFIX      = {
    'TOTAL_BRUT': 'brut_', 'TOTAL_MUTU': 'mutu_',
    'TOTAL_CONT': 'cont_', 'TOTAL_PREL': 'prel_',
    'af_20000'  : 'af_',   'ir_9999'   : 'ir_',
}
VAR_SINGLE_COL     = ['ir_9999', 'af_20000']
SEUIL_MULTI_SOURCE = 0.5


def find_anomaly_source(df, client, cat, var_name, start_date):
    prefix = VAR_TO_PREFIX.get(var_name, '')
    if not prefix:
        return pd.DataFrame()
    if var_name in VAR_SINGLE_COL:
        return pd.DataFrame([{
            'colonne': var_name, 'val_anomalie': None,
            'mediane_hist': None, 'ecart_pct': None,
            'is_source': True, 'est_nouveau': False, 'est_disparu': False,
        }])
    all_cols  = [c for c in df.columns if c.startswith(prefix)]
    df_client = df[
        (df['numero_benef'].astype(str) == str(client)) &
        (df['code_payment_agregator'].astype(str) == str(cat))
    ].copy()
    if df_client.empty or not all_cols:
        return pd.DataFrame()
    active_cols = [c for c in all_cols if df_client[c].fillna(0).max() > 0]
    if not active_cols:
        return pd.DataFrame()

    sort_col  = 'time_idx' if 'time_idx' in df_client.columns else 'start_date'
    df_client = df_client.sort_values(sort_col)
    df_client['term_label'] = (
        '01/' + df_client['mois'].astype(str).str.zfill(2) + '/' +
        df_client['annee'].astype(str)
    )
    df_anom = df_client[df_client['term_label'] == start_date]
    df_hist = df_client[df_client['term_label'] != start_date]
    if df_anom.empty:
        return pd.DataFrame()

    resultats = []
    for col in active_cols:
        hist_vals    = df_hist[col].fillna(0).values
        hist_vals    = hist_vals[hist_vals > 0]
        mediane_hist = float(np.median(hist_vals)) if len(hist_vals) > 0 else 0.0
        val_anom     = float(df_anom[col].fillna(0).sum())
        if mediane_hist > 0:
            ecart_pct = abs(val_anom - mediane_hist) / mediane_hist * 100
        elif val_anom > 0:
            ecart_pct = 100.0
        else:
            ecart_pct = 0.0
        resultats.append({
            'colonne'     : col,
            'val_anomalie': round(val_anom, 2),
            'mediane_hist': round(mediane_hist, 2),
            'ecart_pct'   : round(ecart_pct, 2),
            'est_nouveau' : mediane_hist == 0 and val_anom > 0,
            'est_disparu' : mediane_hist > 0  and val_anom == 0,
        })

    df_res    = pd.DataFrame(resultats).sort_values(
        'ecart_pct', ascending=False
    ).reset_index(drop=True)
    ecart_max = df_res['ecart_pct'].max()
    if ecart_max > 0:
        df_res['is_source'] = df_res['ecart_pct'] >= ecart_max * SEUIL_MULTI_SOURCE
    else:
        df_res['is_source'] = False
        df_res.loc[0, 'is_source'] = True
    return df_res


def run_drilldown(df_original, df_rb_final):
    print("\n" + "="*60)
    print("DRILL-DOWN")
    print("="*60)

    df_original = df_original.copy()
    df_original['numero_benef']           = df_original['numero_benef'].astype(str)
    df_original['code_payment_agregator'] = df_original['code_payment_agregator'].astype(str)
    df_original['mois']  = pd.to_datetime(
        df_original['start_date'], errors='coerce'
    ).dt.month.astype(str).str.zfill(2)
    df_original['annee'] = pd.to_datetime(
        df_original['start_date'], errors='coerce'
    ).dt.year.astype(str)

    df_rb     = df_rb_final.copy()
    df_rb     = df_rb.loc[:, ~df_rb.columns.duplicated()]
    col_cat   = 'code_payment_agregator' if 'code_payment_agregator' \
                in df_rb.columns else 'categorie'
    col_vars  = 'variable_anomalie' if 'variable_anomalie' \
                in df_rb.columns else 'variables_anomalie'
    col_score = 'score_final' if 'score_final' in df_rb.columns else 'score'

    df_rb['_start_corr'] = pd.to_datetime(df_rb['start_date'], errors='coerce')
    df_rb['_start_corr'] = pd.to_datetime({
        'year' : df_rb['_start_corr'].dt.year,
        'month': df_rb['_start_corr'].dt.day,
        'day'  : 1
    })
    df_rb['_start_label'] = (
        '01/' +
        df_rb['_start_corr'].dt.month.astype(str).str.zfill(2) + '/' +
        df_rb['_start_corr'].dt.year.astype(str)
    )

    resultats = []
    for i, row in df_rb.iterrows():
        client     = str(row['numero_benef'])
        cat        = str(row[col_cat])
        start_date = str(row['_start_label'])
        score      = float(row.get(col_score, 0))
        niveau     = str(row.get('niveau_label', ''))
        aff_id     = str(row.get('affiliation_id', ''))

        if i % 100 == 0:
            print(f"  {i}/{len(df_rb)}...")

        for var_name in [v.strip() for v in str(row[col_vars]).split(',')]:
            df_source = find_anomaly_source(
                df_original, client, cat, var_name, start_date
            )
            if df_source.empty:
                resultats.append({
                    'numero_benef'          : client,
                    'affiliation_id'        : aff_id,
                    'variable_agregee'      : var_name,
                    'colonne_source'        : 'Non trouvée',
                    'colonnes_sources'      : 'Non trouvée',
                    'val_anomalie'          : None,
                    'mediane_hist'          : None,
                    'ecart_pct_source'      : None,
                    'type_anomalie'         : 'Non trouvée',
                    'start_date'            : start_date,
                    'code_payment_agregator': cat,
                    col_score               : score,
                    'niveau_label'          : niveau,
                })
                continue

            df_sources       = df_source[df_source['is_source']].copy()
            if df_sources.empty:
                df_sources   = df_source.head(1)
            colonnes_sources = ' | '.join(df_sources['colonne'].tolist())

            for _, src in df_sources.iterrows():
                ecart_pct = float(src.get('ecart_pct', 0) or 0)
                if   src.get('est_nouveau', False): type_anom = 'Nouveau paiement'
                elif src.get('est_disparu', False): type_anom = 'Paiement disparu'
                elif ecart_pct > 100:               type_anom = 'Spike élevé'
                else:                               type_anom = 'Variation anormale'
                resultats.append({
                    'numero_benef'          : client,
                    'affiliation_id'        : aff_id,
                    'variable_agregee'      : var_name,
                    'colonne_source'        : src['colonne'],
                    'colonnes_sources'      : colonnes_sources,
                    'val_anomalie'          : src['val_anomalie'],
                    'mediane_hist'          : src['mediane_hist'],
                    'ecart_pct_source'      : ecart_pct,
                    'type_anomalie'         : type_anom,
                    'start_date'            : start_date,
                    'code_payment_agregator': cat,
                    col_score               : score,
                    'niveau_label'          : niveau,
                })

    df_res = pd.DataFrame(resultats)
    if not df_res.empty:
        df_res = df_res.sort_values(
            [col_score, 'ecart_pct_source'], ascending=False
        ).reset_index(drop=True)
        df_res.to_csv('drilldown_anomalies.csv',
                      index=False, encoding='utf-8-sig')
    print(f"Drill-down : {len(df_res)} lignes")
    return df_res


def print_statistiques(data, df_anomalies, df_rb, df_drilldown):
    total     = data['numero_benef'].nunique()
    n_lstm    = df_anomalies['numero_benef'].nunique() \
                if not df_anomalies.empty else 0
    col_score = 'score_final' if 'score_final' in df_rb.columns else 'score'
    col_cat   = 'code_payment_agregator' if 'code_payment_agregator' \
                in df_rb.columns else 'categorie'

    print(f"\n{'='*65}")
    print(f"RÉSUMÉ PIPELINE")
    print(f"{'='*65}")
    print(f"\nLSTM-AE")
    print(f"  Clients analysés    : {total}")
    print(f"  Suspects détectés   : {n_lstm} ({n_lstm/total*100:.2f}%)")
    print(f"  Anomalies (lignes)  : {len(df_anomalies)}")
    if not df_anomalies.empty:
        print(f"\n  Par catégorie :")
        print(df_anomalies.groupby('code_payment_agregator')[
            'numero_benef'].nunique().to_string())

    if not df_rb.empty:
        n_rb = df_rb['numero_benef'].nunique()
        print(f"\nRESEAU BAYESIEN")
        print(f"  Confirmés           : {n_rb} ({n_rb/n_lstm*100:.1f}% des suspects)")
        print(f"  Taux global         : {n_rb/total*100:.2f}%")
        print(f"  Filtrés (faux pos.) : {n_lstm - n_rb}")
        print(f"\n  Par catégorie :")
        print(df_rb.groupby(col_cat)['numero_benef'].nunique().to_string())
        if 'niveau_label' in df_rb.columns:
            print(f"\n  Par niveau :")
            print(df_rb.groupby('niveau_label')['numero_benef'].nunique().to_string())

    if not df_drilldown.empty:
        print(f"\nDRILL-DOWN")
        print(f"  Lignes localisées   : {len(df_drilldown)}")
        print(f"  Non trouvées        : "
              f"{(df_drilldown['colonne_source']=='Non trouvée').sum()}")
        if 'type_anomalie' in df_drilldown.columns:
            print(f"\n  Par type :")
            print(df_drilldown.groupby('type_anomalie')[
                col_score].count().to_string())

    print(f"\n{'='*65}")
    print(f"  Total  : {total}")
    print(f"  LSTM   : {n_lstm} ({n_lstm/total*100:.2f}%)")
    if not df_rb.empty:
        n_rb = df_rb['numero_benef'].nunique()
        print(f"  RB     : {n_rb} ({n_rb/total*100:.2f}%)")
        print(f"  Filtre : {(1-n_rb/n_lstm)*100:.1f}% faux positifs éliminés")
    print(f"{'='*65}\n")


def run_inference(data=None, data_original=None):

    # si data n'est pas fourni on lance le preprocessing depuis DATA_PATH
    if data is None:
        import importlib.util as _ilu_prep
        _spec  = _ilu_prep.spec_from_file_location('Preprocessing', PREPROCESSING_PATH)
        _mod   = _ilu_prep.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        print("\nPreprocessing en cours...", flush=True)
        data, data_original = _mod.run_preprocessing(DATA_PATH)
        print("Preprocessing terminé", flush=True)

    if data_original is None:
        data_original = data

    print("\n" + "="*65)
    print("PIPELINE INFERENCE - CHARGEMENT DIRECT .pkl")
    print("="*65)

    data = data.copy()
    data['numero_benef']           = data['numero_benef'].astype(str)
    data['annee']                  = data['annee'].astype(int)
    data['mois']                   = data['mois'].astype(int)
    data['code_payment_agregator'] = data['code_payment_agregator'].astype(str)

    print("\nChargement LSTM-AE...", flush=True)
    scalers = joblib.load(LSTM_SCALERS_PATH)
    model   = LSTMAutoEncoder(
        n_features=len(FEATURES_INPUT),
        hidden_size=64, latent_size=32,
        n_layers=2, dropout=0.1
    ).to(DEVICE)
    model.load_state_dict(torch.load(LSTM_MODEL_PATH, map_location=DEVICE))
    model.eval()
    print(f"  LSTM chargé    : {LSTM_MODEL_PATH}", flush=True)
    print(f"  Scalers chargés: {LSTM_SCALERS_PATH}", flush=True)

    print("\nEtape 1 : LSTM-AE sur tous les clients...", flush=True)
    seq, mask, meta, cols_feat = build_sequences_all(data, scalers)
    thresholds   = compute_thresholds(model, seq, mask, cols_feat)
    df_anomalies = detect_anomalies(
        model, seq, mask, meta, cols_feat, thresholds, data
    )
    print("LSTM-AE termine", flush=True)

    if DEBUG:
        df_anomalies.to_csv('lstm_ae_anomalies_test.csv',
                            index=False, encoding='utf-8-sig')

    print("\nEtape 2 : Reseau Bayesien...", flush=True)
    print(f"  Suspects LSTM : {df_anomalies['numero_benef'].nunique()} clients", flush=True)
    print(f"  Lignes LSTM   : {len(df_anomalies)} -> envoyees directement au RB", flush=True)

    models_rb = joblib.load(RB_MODELS_PATH)
    print(f"  Modeles RB charges : {len(models_rb)}", flush=True)

    _spec  = _ilu.spec_from_file_location('rb', RB_CODE_PATH)
    rb_mod = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(rb_mod)
    rb_mod._MODELS_RB = models_rb

    df_rb = rb_mod.run_rb_inference(
        df_complet       = data,
        df_lstm_suspects = df_anomalies,
        models_rb        = models_rb,
    )
    print("RB termine", flush=True)

    if DEBUG:
        df_rb.to_csv('rb_anomalies_confirmes.csv',
                     index=False, encoding='utf-8-sig')

    print("\nEtape 3 : Drill-down...", flush=True)
    df_drilldown = run_drilldown(data_original, df_rb)
    print("Drill-down termine", flush=True)

    print_statistiques(data, df_anomalies, df_rb, df_drilldown)

    return df_anomalies, df_rb, df_drilldown